let constantName = "Steve"
var optionalLastName: String? = "Jobs"
optionalLastName = "Jobs"

var anotherLastName = "Wozniak"

switch (anotherLastName){
case anotherLastName: anotherLastName
default: anotherLastName
    
    }

if let constantName = Int(constantName) {
    print("The name is \(constantName) the last name \(anotherLastName)")
}else{
    print("The name is \(constantName) \(anotherLastName)")
}

